﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using UniJSON;
using Unity.Collections;

namespace UniGLTF
{
    /// <summary>
    /// Low-level API.
    /// Parse from specified path & specified binary.
    /// </summary>
    public sealed class GlbLowLevelParser
    {
        public static readonly string UniqueFixResourceSuffix = "__UNIGLTF__DUPLICATED__";
        private static readonly Regex _removeUniqueFixResourceSuffix = new Regex($@"^(.+){UniqueFixResourceSuffix}(\d+)$");

        private readonly string _path;
        private readonly ReadOnlyMemory<byte> _binary;

        public GlbLowLevelParser(string path, byte[] specifiedBinary)
        {
            _path = path;
            _binary = specifiedBinary;
        }

        public GlbLowLevelParser(string path, NativeArray<byte> specifiedBinary)
        {
            _path = path;
            _binary = specifiedBinary.AsMemory();
        }

        public GltfData Parse() => Parse(_path, _binary);

        public static GltfData Parse(string path, NativeArray<byte> binary) =>
            Parse(path, binary.AsMemory());

        public static GltfData Parse(string path, byte[] binary) =>
            Parse(path, binary.AsMemory());

        public static GltfData Parse(string path, ReadOnlyMemory<byte> binary)
        {
            try
            {
                var chunks = ParseGlbChunks(binary);
                var jsonBytes = chunks[0].Bytes;
                return ParseGltf(
                    path,
                    jsonBytes,
                    chunks,
                    default,
                    new MigrationFlags()
                );
            }
            catch (StackOverflowException ex)
            {
                throw new Exception("[UniVRM Import Error] json parsing failed, nesting is too deep.\n" + ex);
            }
            catch
            {
                throw;
            }
        }

        public static List<GlbChunk> ParseGlbChunks(ReadOnlyMemory<byte> data)
        {
            var chunks = glbImporter.ParseGlbChunks(data);

            if (chunks.Count < 2)
            {
                throw new Exception("unknown chunk count: " + chunks.Count);
            }

            if (chunks[0].ChunkType != GlbChunkType.JSON)
            {
                throw new Exception("chunk 0 is not JSON");
            }

            if (chunks[1].ChunkType != GlbChunkType.BIN)
            {
                throw new Exception("chunk 1 is not BIN");
            }

            return chunks;
        }

        public static GltfData ParseGltf(string path, string json, IReadOnlyList<GlbChunk> chunks, IStorage storage, MigrationFlags migrationFlags)
        {
            return ParseGltf(path, Utf8String.From(json), chunks, storage, migrationFlags);
        }

        internal static GltfData ParseGltf(string path, Utf8String json, IReadOnlyList<GlbChunk> chunks, IStorage storage, MigrationFlags migrationFlags)
        {
            return ParseGltf(path, json.Bytes, chunks, storage, migrationFlags);
        }

        public static GltfData ParseGltf(string path, ReadOnlyMemory<byte> json, IReadOnlyList<GlbChunk> chunks, IStorage storage, MigrationFlags migrationFlags)
        {
            var jsonNode = json.ParseAsJson();
            var GLTF = GltfDeserializer.Deserialize(jsonNode);
            if (!GLTF.asset.version.StartsWith("2"))
            {
                throw new UniGLTFException("unknown gltf version {0}", GLTF.asset.version);
            }

            // Version Compatibility
            RestoreOlderVersionValues(jsonNode, GLTF);

            FixMeshNameUnique(GLTF);
            FixBlendShapeNameUnique(GLTF);
            foreach (var image in GLTF.images)
            {
                image.uri = PrepareUri(image.uri);
            }
            FixTextureNameUnique(GLTF);
            FixMaterialNameUnique(GLTF);
            FixNodeName(GLTF);
            FixAnimationNameUnique(GLTF);

            return new GltfData(path, json, GLTF, chunks, storage, migrationFlags);
        }

        private static void FixMeshNameUnique(glTF GLTF)
        {
            var used = new HashSet<string>();
            foreach (var mesh in GLTF.meshes)
            {
                if (string.IsNullOrEmpty(mesh.name))
                {
                    // empty
                    mesh.name = "mesh_" + Guid.NewGuid().ToString("N");
                    used.Add(mesh.name);
                }
                else
                {
                    var lower = mesh.name.ToLower();
                    if (used.Contains(lower))
                    {
                        // rename
                        var uname = lower + "_" + Guid.NewGuid().ToString("N");
                        mesh.name = uname;
                        lower = uname;
                    }
                    used.Add(lower);
                }
            }
        }

        // https://github.com/vrm-c/UniVRM/issues/2619
        private static void FixBlendShapeNameUnique(glTF GLTF)
        {
            foreach (var mesh in GLTF.meshes)
            {
                /// https://github.com/KhronosGroup/glTF/pull/1631/files
                if (gltf_mesh_extras_targetNames.TryGet(mesh, out var targetNames))
                {
                    var used = new HashSet<string>();
                    int rename = 0;
                    for (int i = 0; i < targetNames.Count; ++i)
                    {
                        var target_name = targetNames[i];
                        if (string.IsNullOrEmpty(target_name))
                        {
                            // no name
                            targetNames[i] = $"__{i}__";
                            UniGLTFLogger.Log($"rename blendshape: {mesh.name}[{i}]{target_name} => {targetNames[i]}");
                            rename += 1;
                        }
                        else if (used.Contains(target_name))
                        {
                            // rename
                            var uname = $"__{i}__{target_name}";
                            targetNames[i] = uname;
                            UniGLTFLogger.Log($"rename blendshape: {mesh.name}[{i}]{target_name} => {targetNames[i]}");
                            rename += 1;
                        }
                        used.Add(targetNames[i]);
                    }
                    if (rename > 0)
                    {

                        // var extrans = new Dictionary<string, JsonNode>()
                        // {
                        //     {"targetNames", targetNames },
                        var f = new JsonFormatter();
                        f.BeginMap();
                        f.Key("targetNames");
                        {
                            f.BeginList();
                            foreach (var name in targetNames)
                            {
                                f.Value(name);
                            }
                            f.EndList();
                        }
                        f.EndMap();
                        var json = f.ToString();
                        mesh.extras = new UniGLTF.glTFExtensionImport(JsonParser.Parse(json));
                    }
                }
            }
        }

        private static void RenameImageFromTexture(glTF GLTF, int i)
        {
            foreach (var texture in GLTF.textures)
            {
                if (texture.source == i)
                {
                    if (!string.IsNullOrEmpty(texture.name))
                    {
                        GLTF.images[i].name = texture.name;
                        return;
                    }
                }
            }
        }

        /// <summary>
        /// image.uri を前理
        /// </summary>
        /// <param name="uri"></param>
        /// <returns></returns>
        public static string PrepareUri(string uri)
        {
            if (string.IsNullOrEmpty(uri))
            {
                return uri;
            }

            if (uri.StartsWith("./"))
            {
                // skip
                uri = uri.Substring(2);
            }

            // %20 to ' ' etc...
            var unescape = Uri.UnescapeDataString(uri);
            return unescape;
        }

        /// <summary>
        /// gltfTexture.name を Unity Asset 名として運用する。
        /// ユニークである必要がある。
        /// </summary>
        private static void FixTextureNameUnique(glTF GLTF)
        {
            // NOTE: Windows FileSystem は大文字小文字の違いは同名ファイルとして扱ってしまうため, IgnoreCase で評価する.
            var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (var textureIdx = 0; textureIdx < GLTF.textures.Count; ++textureIdx)
            {
                var gltfTexture = GLTF.textures[textureIdx];
                if (gltfTexture.source.HasValidIndex())
                {
                    var gltfImage = GLTF.images[gltfTexture.source.Value];
                    if (!string.IsNullOrEmpty(gltfImage.uri) && !gltfImage.uri.StartsWith("data:"))
                    {
                        // from image uri
                        gltfTexture.name = Path.GetFileNameWithoutExtension(gltfImage.uri);
                    }
                    if (string.IsNullOrEmpty(gltfTexture.name))
                    {
                        // use image name
                        gltfTexture.name = gltfImage.name;
                    }
                }
                if (string.IsNullOrEmpty(gltfTexture.name))
                {
                    gltfTexture.name = $"texture_{textureIdx}";
                }

                gltfTexture.name = FixNameUnique(used, gltfTexture.name);
            }
        }

        private static void FixMaterialNameUnique(glTF GLTF)
        {
            // NOTE: Windows FileSystem は大文字小文字の違いは同名ファイルとして扱ってしまうため, IgnoreCase で評価する.
            var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (var materialIdx = 0; materialIdx < GLTF.materials.Count; ++materialIdx)
            {
                var material = GLTF.materials[materialIdx];

                if (string.IsNullOrEmpty(material.name))
                {
                    material.name = $"material_{materialIdx}";
                }

                material.name = FixNameUnique(used, material.name);
            }
        }

        /// <summary>
        /// rename empty name to $"{index}"
        /// </summary>
        private static void FixNodeName(glTF GLTF)
        {
            for (var i = 0; i < GLTF.nodes.Count; ++i)
            {
                var node = GLTF.nodes[i];
                if (string.IsNullOrWhiteSpace(node.name))
                {
                    node.name = $"{i}";
                }
            }
        }

        private static void FixAnimationNameUnique(glTF GLTF)
        {
            // NOTE: Windows FileSystem は大文字小文字の違いは同名ファイルとして扱ってしまうため, IgnoreCase で評価する.
            var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < GLTF.animations.Count; ++i)
            {
                var animation = GLTF.animations[i];

                if (string.IsNullOrEmpty(animation.name))
                {
                    animation.name = $"animation_{i}";
                }

                animation.name = FixNameUnique(used, animation.name);
            }
        }

        private static void RestoreOlderVersionValues(JsonNode jsonNode, glTF GLTF)
        {
            for (int i = 0; i < GLTF.images.Count; ++i)
            {
                if (string.IsNullOrEmpty(GLTF.images[i].name))
                {
                    try
                    {
                        var extraName = jsonNode["images"][i]["extra"]["name"].Value.GetString();
                        if (!string.IsNullOrEmpty(extraName))
                        {
                            GLTF.images[i].name = extraName;
                        }
                    }
                    catch (Exception)
                    {
                        // do nothing
                    }
                }
            }
        }

        public static void AppendImageExtension(glTFImage texture, string extension)
        {
            if (!texture.name.EndsWith(extension))
            {
                texture.name = texture.name + extension;
            }
        }

        public static string FixNameUnique(HashSet<string> used, string originalName)
        {
            if (used.Add(originalName))
            {
                return originalName;
            }

            var duplicatedIdx = 2;
            while (true)
            {
                var newName = $"{originalName}{UniqueFixResourceSuffix}{duplicatedIdx++}";
                if (used.Add(newName))
                {
                    return newName;
                }
            }
        }

        public static bool TryGetOriginalName(string name, out string originalName)
        {
            var match = _removeUniqueFixResourceSuffix.Match(name);
            if (match.Success)
            {
                originalName = match.Groups[1].Value;
                return true;
            }
            else
            {
                originalName = name;
                return false;
            }
        }
    }
}